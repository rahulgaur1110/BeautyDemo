const List = [
    {
      id: "1",
      name: "Collision",
      category: "Movie",
      genre:"Thriller",
    //   title: "Ermal Meta tour 2021 presto tickets online1", 
      language: "English",
      description:
        "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.",
      image: require("../Images/slider.webp"),
      catImage: require("../Images/Category1.png"),
      userToken:'token1',
      videoURL: "https://www.w3schools.com/html/mov_bbb.mp4"
    },
    {
      id: "2",
      name: "The Fury",
      category: "Series",
      genre:"Action",
    //   title: "Ermal Meta tour 2021 presto tickets online1", 
      language: "Zulu",
      description:
        "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.",
      image: require("../Images/slider2.jpg"),
      catImage: require("../Images/Category2.png"),
      userToken:'token2',
      videoURL: "https://www.w3schools.com/tags/movie.mp4"
      
    },
    {
      id: "3",
      name: "Vanity",
      category: "Kids",
      genre:"Romance",
    //   title: "Ermal Meta tour 2021 presto tickets online1", 
      language: "Tsonga",
      description:
        "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.",
      image: require("../Images/slider3.jpg"),
      catImage: require("../Images/Category3.png"),
      userToken:'token3',
      videoURL: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
      // https://samplelib.com/lib/preview/mp4/sample-5s.mp4
    },
    {
      id: "4",
      name: "Amandla",
      category: "TV Show",
      genre:"Comedy",
    //   title: "Ermal Meta tour 2021 presto tickets online1", 
      language: "Xhosa",
      description:
        "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.",
      image: require("../Images/slider4.jpg"),
      catImage: require("../Images/Category4.png"),
      userToken:'token4',
      videoURL: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"
      
    },
    {
      id: "5",
      name: "Thando",
      category: "Movie",
      genre:"Drama",
    //   title: "Ermal Meta tour 2021 presto tickets online1", 
      language: "Tswana",
      description:
        "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.",
      image: require("../Images/slider5.jpg"),
      catImage: require("../Images/Category1.png"),
      userToken:'token5',
      videoURL: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"
      
    },
   
  ];
  
  export { List };




