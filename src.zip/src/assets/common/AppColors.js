const AppColor = {
    black: '#fff',
    white: '#000',
    primaryColor: '#ED1C24'
}

export default AppColor;